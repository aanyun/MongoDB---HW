
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.io.BufferedReader; 
import java.io.File; 
import java.io.FileNotFoundException;
import java.io.FileReader; 
import java.io.IOException;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
public class rating { 
    public static void main(String[] args) throws MongoException, NumberFormatException, IOException {
        Mongo mg = new Mongo();
        mg.dropDatabase("test");
        DB db = mg.getDB("test");       
        DBCollection ratings = db.getCollection("ratings");
        String fileName1="C:\\Users\\Anyun\\Desktop\\rating.dat";
		File file1=new File(fileName1);
		BufferedReader br = null;
		 
		  int movieid=0;
		  int userid=0;
		  int timestamp=0;
		
		  float rate;
		  int r=0;
		  		  
		 
			  br=new BufferedReader(new FileReader(file1));
			
			  StringBuffer sb=new StringBuffer();
			  String line=null;
			  String[] rec=null;
			 
			  
			 
			   
			   while((line=br.readLine())!=null){
				   r++;
				System.out.println(r);
			    rec=line.split("::");
			    userid=Integer.parseInt(rec[0]);
			    movieid=Integer.parseInt(rec[1]);
			    rate=Float.parseFloat(rec[2]);
			    timestamp=Integer.parseInt(rec[3]);
			    
			    BasicDBObject bo = new BasicDBObject();			   
			    bo.put("movieid", movieid);			  
			   
			   		    
			    bo.put("userid",userid);
			    bo.put("rating", rate);
			    bo.put("timestamp", timestamp);
			    
			   
			    ratings.insert(bo);
               
			   }
			    
			  
                        
			   
			   
			
	// showmovieid(ratings,1);
   showsameuserid(ratings,1);
 //  showsimilaruserid(ratings,1);     
 
			 
	getallmovieavg(ratings);
     getavgratebymovie(ratings,1);
      //  showdata(ratings);
      
  
}
    public static void getallmovieavg(DBCollection ratings)
    {   ArrayList list=new ArrayList();
    	list=getmovieidset(ratings);
       Iterator it1 = list.iterator(); 
       while(it1.hasNext()){ 
            getavgratebymovie(ratings,it1.next()); 
    } 
     }
    
    
    public static void getavgratebymovie(DBCollection ratings,Object object)
    {
    	BasicDBObject co= new BasicDBObject();
	    co.put("rating",1);
	    BasicDBObject cp= new BasicDBObject();
	    cp.put("movieid",object);
	    
	    DBCursor cu = ratings.find(cp,co);  
	    int ratenum=cu.count();
	    double rate;
	 //   System.out.println(ratenum);
	    double sum=0.00;
	    
	    	while(cu.hasNext()){
		         DBObject result= cu.next();
	    	     rate=(double) result.get("rating");
	             sum=sum+rate;
	    	//System.out.println(sum);
	     }
	   double avg=sum/ratenum;
	   System.out.println("movie No."+object +"average rating is "+avg);
    }
    
    
    public static void showsimilaruserid(DBCollection ratings,int userid)
    {  ArrayList movie=new ArrayList();
	   ArrayList common=new ArrayList();
    	BasicDBObject co= new BasicDBObject();
	    co.put("userid",userid);
	    DBCursor cu = ratings.find(co);   
	   int moviesize=0; 
	    
	    while (cu.hasNext()) {
	       		 
	    	int a= (int) cu.next().get("movieid");
	    	 movie.add(a);
	    	// System.out.println("movieid:"+a);
	    	
	    	 BasicDBObject newd= new BasicDBObject();
	    	 newd.put("movieid",a);
	    	 moviesize++;
	    	 DBCursor dbcursor=ratings.find(newd);
	    	 
	    	 while(dbcursor.hasNext()){
	         DBObject result= dbcursor.next();
	     
	        	 int usersId = (int) result.get("userid");
	        	 
	        	 common.add(usersId);
	        
	        	 }
	    	 
	    	 }
	    
	      
	   // System.out.println("userid"+ userId);
	    Map <Object,Integer> map = new HashMap <Object,Integer>(); 
       for(Object o :common){ 
           map.put(o, map.get(o)==null?1:map.get(o)+1); 
            }
       ArrayList similaruserid=new ArrayList();
       for(Object key:map.keySet())
       	   if(map.get(key).equals(moviesize))similaruserid.add(key);
       System.out.println("similar user's id: "+similaruserid);
       }
    
    public static int moviesize(DBCollection ratings,Object key)
    {  ArrayList movie=new ArrayList();	  
   	   BasicDBObject co= new BasicDBObject();
	   co.put("userid",key);
	   DBCursor cu = ratings.find(co);   
	   int moviesize=0; 	    
	    while (cu.hasNext()) {	       	 
	    	int a= (int) cu.next().get("movieid");
	    	 movie.add(a);	    
	    	 BasicDBObject newdb= new BasicDBObject();
	    	 newdb.put("userid",key);
	    	 BasicDBObject newd= new BasicDBObject();
	    	 newd.put("movieid",a);
	    	 moviesize++;
	    	 DBCursor dbcursor=ratings.find(newd,newdb);
	    		
	        	 }
	    
	   // System.out.println("user 1 rated movie:"+movie.size());
    	return(movie.size());
    }
    
    public static void showsameuserid(DBCollection ratings,int userid)
    {  ArrayList movie=new ArrayList();
	   ArrayList common=new ArrayList();
   	   BasicDBObject co= new BasicDBObject();
	    co.put("userid",userid);
	    DBCursor cu = ratings.find(co);   
	    int moviesize=0; 
	    
	    while (cu.hasNext()) {
	       		 
	    	int a= (int) cu.next().get("movieid");
	    	 movie.add(a);
	    	// System.out.println("movieid:"+a);
	    	
	    	 BasicDBObject newd= new BasicDBObject();
	    	 newd.put("movieid",a);
	    	 moviesize++;
	    	 DBCursor dbcursor=ratings.find(newd);
	    	 
	    	 while(dbcursor.hasNext()){
	         DBObject result= dbcursor.next();
	     
	        	 int usersId = (int) result.get("userid");
	        	 
	        	 common.add(usersId);
	        
	        	 }
	    	 
	    	 }
	    
	    Map <Object,Integer> map = new HashMap <Object,Integer>(); 
       for(Object o :common){ 
          map.put(o, map.get(o)==null?1:map.get(o)+1); 
           }
       ArrayList sameuserid=new ArrayList();
         for(Object key:map.keySet())
      	   if(map.get(key).equals(moviesize))
      	   {   if(moviesize(ratings,key)==moviesize)  	      
      	        sameuserid.add(key);              
            }
         
         System.out.println("same user's id set: "+sameuserid);
    }
    public static ArrayList getmovieidset(DBCollection ratings)
    {   DBCursor cur = ratings.find(); 
        int mid=0;
        ArrayList movieset=new ArrayList();
    	while (cur.hasNext()) 
    	{ mid = (int)cur.next().get("movieid");
    	movieset.add(mid);}
    	removeDuplicate(movieset);
    //	 System.out.println("movieset "+movieset);
    	 return(movieset);
    	}
    public static void removeDuplicate(ArrayList arlList)  
    {  
     HashSet h = new HashSet(arlList);  
     arlList.clear();  
     arlList.addAll(h);  
    }  
    public static void showdata(DBCollection ratings)
    {   DBCursor cur = ratings.find(); 
    	while (cur.hasNext()) 
        System.out.println(cur.next());
    	}
}
 