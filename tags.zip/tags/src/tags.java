import java.awt.List;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.io.BufferedReader; 
import java.io.File; 
import java.io.FileNotFoundException;
import java.io.FileReader; 
import java.io.IOException; 

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.util.JSON;
 

public class tags {
 
    public static void main(String[] args) throws UnknownHostException, MongoException {
        Mongo mg = new Mongo();           
        mg.dropDatabase("test");
        DB db = mg.getDB("test");              
        DBCollection movies = db.getCollection("movies");
        int r=0;
        String fileName1="c:\\Users\\Anyun\\Desktop\\tag.dat";
		File file1=new File(fileName1);
		BufferedReader br = null;
	
		  int movieid=0;
		  int userid=0;
		  int timestamp=0;
		  String tag;	
		  
		  try {
			   br=new BufferedReader(new FileReader(file1));
			  } catch (FileNotFoundException e) {
			   e.printStackTrace();
			  }
			  StringBuffer sb=new StringBuffer();
			  String line=null;
			  String[] rec=null;
			  
			  
			  try {
				
			   
			   while((line=br.readLine())!=null){
				   r++;
				   System.out.println(r);   
			    rec=line.split("::");
			    userid=Integer.parseInt(rec[0]);
			    movieid=Integer.parseInt(rec[1]);
			    tag=rec[2];
			    timestamp=Integer.parseInt(rec[3]);			
			   
			   
			    BasicDBObject bo = new BasicDBObject();
			    if(movies.find(new BasicDBObject("movieid",movieid)).count()>0)
			    { 
			    				
			    
			     BasicDBObject add = new BasicDBObject();
			     add.put("userid", userid);
			     add.put("tag",tag);
			     add.put("timestamp", timestamp);
			     
			     
			     BasicDBObject update=new BasicDBObject();
			     update.put("$push",new BasicDBObject("tags",add)); 
			     movies.update(new BasicDBObject("movieid",movieid),update);}
			    
			    else{ bo.put("movieid", movieid);
			    BasicDBList a= new BasicDBList();
			    bo.put("tags", a);
			    
			    
			    BasicDBObject b= new BasicDBObject();
			     b.put("userid", userid);
			     b.put("tag",tag);
			     b.put("timestamp", timestamp);
			    
			    a.add(b);
			    movies.insert(bo);
			    
			    }
			    
			   }
             
			  } catch (IOException e1) {
			   e1.printStackTrace();
			  }
        
	
        
  
    
   	//showdata(movies);
    showmosttagmovie(movies);
    showmoviesize(movies);
      
    }
    public static void showmosttagmovie(DBCollection movies)
    {   ArrayList movie=new ArrayList();
    	DBCursor cur = movies.find();
    	int sum=0;
    	int movieid=0;
    	while (cur.hasNext()){ 
    		int a= (int) cur.next().get("movieid");	
    		int i=0;
	    	 DBCursor dbcursor= movies.find(new BasicDBObject("movieid",a),new BasicDBObject("tags",1)); 
	    	 if(dbcursor.hasNext()){
	         DBObject result= dbcursor.next();	     		         
	         ArrayList<BasicDBObject> query=(ArrayList<BasicDBObject>) result.get("tags");
	         for(BasicDBObject embedded : query){
	        	i++;
	        	if(i>sum){sum=i;movieid=a;}}
	         }
          movie.add(i);
         // System.out.println("movie No. "+a+" was tagged by "+i+" times");
        
    	} 
    	System.out.println("The most tagged movie is No. "+movieid+" by "+sum+" times");
    	}
  
    public static void showmoviesize(DBCollection movies){
        System.out.println("The number of Movies which was tagged as 'based on a book' was "+movies.find(new BasicDBObject("tags.tag","based on a book")).count());
    	
    }
    public static void showdata(DBCollection movies)
    {  DBCursor cur = movies.find();
    	while (cur.hasNext()) 
        System.out.println(cur.next());}
}


