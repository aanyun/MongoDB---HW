import java.awt.List;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.io.BufferedReader; 
import java.io.File; 
import java.io.FileNotFoundException;
import java.io.FileReader; 
import java.io.IOException; 

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoException;
import com.mongodb.util.JSON;
 

public class movies {
 
    public static void main(String[] args) throws UnknownHostException, MongoException {
        Mongo mg = new Mongo();
        mg.dropDatabase("test");
        DB db = mg.getDB("test"); 
        DBCollection users = db.getCollection("users");        
        String fileName1="c:\\Users\\Anyun\\Desktop\\ml-10M100K\\movies.dat";
		  File file1=new File(fileName1);
		  BufferedReader br = null;
		  String name="";
		  int movieid=0;
		  String gen="";		
		  try {
			   br=new BufferedReader(new FileReader(file1));
			  } catch (FileNotFoundException e) {
			   e.printStackTrace();
			  }
			  StringBuffer sb=new StringBuffer();
			  String line=null;
			  String[] rec=null;
			  String[] type=null;
			  ArrayList data = new ArrayList(); 
			  try {
			   
			   while((line=br.readLine())!=null){
			    rec=line.split("::");
			    movieid=Integer.parseInt(rec[0]);
			    name=rec[1];
			    gen=rec[2];
			    BasicDBObject bo = new BasicDBObject();
			    bo.put("movieid", movieid);
			    bo.put("title", name);
			    type=gen.split("\\|");
			    BasicDBList a= new BasicDBList();
			    for (int i=0;i<type.length;i++)
			    {a.add(type[i]);}	
			    bo.put("gen", a);			    
			    data.add(bo);
			    
			   }
			    
			   users.insert(data);
			   
			  } catch (IOException e1) {
			   e1.printStackTrace();
			  }
    
        
       // showdata(users);
        countmoviebygen(users);
        
       
       
        

        
    }
    public static void countmoviebygen(DBCollection movies)
    {     BasicDBObject co= new BasicDBObject();
         co.put("gen","Comedy");
    	 DBCursor cu = movies.find(co);
         System.out.println("Comedy has "+cu.count()); 
      
         System.out.println("Action has "+movies.find(new BasicDBObject("gen","Action")).count()); 
         System.out.println("Adventure has "+movies.find(new BasicDBObject("gen","Adventure")).count());
         System.out.println("Children's has "+movies.find(new BasicDBObject("gen","Children")).count());
         System.out.println("Crime has "+movies.find(new BasicDBObject("gen","Crime")).count());
         System.out.println("Documentary has "+movies.find(new BasicDBObject("gen","Documentary")).count());
         System.out.println("Drama has "+movies.find(new BasicDBObject("gen","Drama")).count());
         System.out.println("Fantasy has "+movies.find(new BasicDBObject("gen","Fantasy")).count());
         System.out.println("Film-Noir has "+movies.find(new BasicDBObject("gen","Film-Noir")).count());
         System.out.println("Musical has "+movies.find(new BasicDBObject("gen","Musical")).count());
         System.out.println("Romance has "+movies.find(new BasicDBObject("gen","Romance")).count());
         System.out.println("Sci-Fi has "+movies.find(new BasicDBObject("gen","Sci-Fi")).count());
         System.out.println("Thriller has "+movies.find(new BasicDBObject("gen","Thriller")).count());
         System.out.println("War has "+movies.find(new BasicDBObject("gen","War")).count());
         System.out.println("Western has "+movies.find(new BasicDBObject("gen","Western")).count());
    }
    public static void showdata(DBCollection movies)
    {   DBCursor cur = movies.find();
    	while (cur.hasNext())
        {
        System.out.println(cur.next());
        }
}
}